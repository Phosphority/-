package com.studentWork.service.impl;

import com.studentWork.entity.Catalog;
import com.studentWork.entity.Manager;
import com.studentWork.mapper.CatalogMapper;
import com.studentWork.service.CatalogService;
import com.studentWork.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;

public class CatalogServiceImpl implements CatalogService {
    @Override
    public List<Catalog> findAll() {
        try(SqlSession session = MybatisUtils.openSqlSession(true)){
            CatalogMapper mapper = session.getMapper(CatalogMapper.class);
            List<Catalog> catalogs = mapper.findAll();
            for(Catalog catalog : catalogs) {
                String flag = catalog.getCatalog_state();
                if(flag.equals("1")) {
                    catalog.setCatalog_state("启用");
                }else {
                    catalog.setCatalog_state("禁用");
                }
            }
            return catalogs;
        }
    }

    @Override
    public Catalog selectCatalogById(Integer catalog_id) {
        try(SqlSession session = MybatisUtils.openSqlSession(true)){
            CatalogMapper mapper = session.getMapper(CatalogMapper.class);
            return mapper.selectCatalogById(catalog_id);
        }
    }

    @Override
    public boolean updateCatalogByName(Catalog catalog) {
        try(SqlSession session = MybatisUtils.openSqlSession(true)){
            CatalogMapper mapper = session.getMapper(CatalogMapper.class);
            int flag = mapper.updateCatalogByName(catalog);
            return flag > 0;
        }
    }

    @Override
    public boolean insertCatalog(Catalog catalog) {
        try(SqlSession session = MybatisUtils.openSqlSession(true)){
            CatalogMapper mapper = session.getMapper(CatalogMapper.class);
            int flag = mapper.insertCatalog(catalog);
            return flag > 0;
        }
    }

    @Override
    public boolean deleteCatalogById(Integer catalog_id) {
        try(SqlSession session = MybatisUtils.openSqlSession(true)){
            CatalogMapper mapper = session.getMapper(CatalogMapper.class);
            int flag = mapper.deleteCatalogById(catalog_id);
            return flag > 0;
        }
    }
}
