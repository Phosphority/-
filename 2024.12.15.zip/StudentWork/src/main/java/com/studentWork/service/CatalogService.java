package com.studentWork.service;

import com.studentWork.entity.Catalog;

import java.util.List;

public interface CatalogService {
    List<Catalog> findAll();
    Catalog selectCatalogById(Integer catalog_id);
    boolean updateCatalogByName(Catalog catalog);
    boolean deleteCatalogById(Integer catalog_id);
    boolean insertCatalog(Catalog catalog);
}
