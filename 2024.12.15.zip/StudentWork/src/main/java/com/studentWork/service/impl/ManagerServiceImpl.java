package com.studentWork.service.impl;

import com.studentWork.dao.ManagerDao;
import com.studentWork.dao.impl.ManagerDaoImpl;
import com.studentWork.entity.Manager;
import com.studentWork.service.ManagerService;
import org.apache.ibatis.session.SqlSession;

import java.sql.SQLException;
import java.util.List;

public class ManagerServiceImpl implements ManagerService {

    @Override
    public boolean login(Manager manager) throws SQLException {
        ManagerDao managerDao = new ManagerDaoImpl();
        Manager manager1 = managerDao.getManagerByNameAndPassword(manager);
        return manager1.getManager_name() != null
                && manager1.getManager_password() != null;
    }

    @Override
    public List<Manager> findAll(Integer nowPage,Integer pageMax) throws SQLException {
        int startNum = (nowPage - 1) * pageMax;
        ManagerDao managerDao = new ManagerDaoImpl();
        List<Manager> managers = managerDao.findAll(startNum, pageMax);
        for(Manager manager : managers) {
            manager.setManager_password("******");
            String flag = manager.getManager_state();
            if(flag.equals("1")) {
                manager.setManager_state("启用");
            }else {
                manager.setManager_state("禁用");
            }
        }
        return managers;
    }

    @Override
    public Integer findAllCount(Integer pageSize) throws SQLException {
        ManagerDao managerDao = new ManagerDaoImpl();
        Integer count = managerDao.findAllCount();
        int maxPage = (count/pageSize);
        if(count%pageSize > 0) {
            maxPage++;
        }
        return maxPage;
    }

    @Override
    public boolean insert(Manager manager) throws SQLException {
        ManagerDao managerDao = new ManagerDaoImpl();
        Integer flag = managerDao.insert(manager);
        return  flag > 0;
    }

    @Override
    public boolean modify(Manager manager) throws SQLException {
        ManagerDao managerDao = new ManagerDaoImpl();
        Integer flag = managerDao.modify(manager);
        return flag > 0;
    }

    @Override
    public Manager findById(Manager manager) throws SQLException {
        ManagerDao managerDao = new ManagerDaoImpl();
        return managerDao.findById(manager);
    }

    @Override
    public boolean deleteManagerById(Integer manager_id) throws SQLException {
        ManagerDao managerDao = new ManagerDaoImpl();
        Integer flag = managerDao.deleteManagerById(manager_id);
        return flag > 0;
    }
}
