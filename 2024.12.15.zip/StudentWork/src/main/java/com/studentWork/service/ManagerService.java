package com.studentWork.service;


import com.studentWork.entity.Manager;

import java.sql.SQLException;
import java.util.List;

public interface ManagerService {
    public boolean login(Manager manager) throws SQLException;
    public List<Manager> findAll(Integer nowPage,Integer maxPage) throws SQLException;
    public Integer findAllCount(Integer nowPageMax)throws SQLException;
    public boolean insert(Manager manager) throws SQLException;
    public boolean modify(Manager manager) throws SQLException;
    public Manager findById(Manager manager) throws SQLException;
    boolean deleteManagerById(Integer managerId) throws SQLException; //��
}
