package com.studentWork.mapper;

import com.studentWork.entity.Catalog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface CatalogMapper {
//    @Select("select * from tb_catalog")
    List<Catalog> findAll();
    Catalog selectCatalogById(Integer catalog_id);
    Integer updateCatalogByName(Catalog catalog);
    Integer deleteCatalogById(Integer catalog_id);
    Integer insertCatalog(Catalog catalog);
//    Catalog selectCatalogByName(String catalog_name);
}
