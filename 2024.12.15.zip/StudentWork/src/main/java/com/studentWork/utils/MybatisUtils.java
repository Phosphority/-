package com.studentWork.utils;


import org.apache.ibatis.datasource.pooled.PooledDataSource;
import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;

import java.io.IOException;

public class MybatisUtils {
    public static SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(initConfiguration());

//    static{
//        try{
//            factory = new SqlSessionFactoryBuilder().build(new FileInputStream("mybatis-config.xml"));
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        }
//    }

    public static Configuration initConfiguration() {
        Configuration configuration = new Configuration();
        PooledDataSource DataSource = new PooledDataSource(
                "com.mysql.jdbc.Driver",
                "jdbc:mysql://localhost:3306/test",
                "root",
                "1911"
        );
        Environment environment = new Environment( "development",new JdbcTransactionFactory(),DataSource);
        configuration.setEnvironment(environment);
        configuration.getTypeAliasRegistry().registerAliases("com.studentWork.entity");
        configuration.addMappers("com.studentWork.mapper");
        configuration.setMapUnderscoreToCamelCase(true);
        return configuration;
    }

    public static SqlSession openSqlSession(boolean autoCommit){
        return factory.openSession(autoCommit);
    }
}
