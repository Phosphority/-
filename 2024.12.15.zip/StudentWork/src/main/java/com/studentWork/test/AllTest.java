package com.studentWork.test;

import com.studentWork.mapper.CatalogMapper;
import com.studentWork.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;
import org.junit.jupiter.api.Test;

public class AllTest {
    @Test
    public void isMapper() {
        try(SqlSession session = MybatisUtils.openSqlSession(true)){
            CatalogMapper mapper = session.getMapper(CatalogMapper.class);
            System.out.println(mapper.findAll());
        }
    }

    @Test
    public void mapperSelectOne() {
        try(SqlSession session = MybatisUtils.openSqlSession(true)){
            CatalogMapper mapper = session.getMapper(CatalogMapper.class);
            System.out.println(mapper.selectCatalogById(3));
        }
    }
}
