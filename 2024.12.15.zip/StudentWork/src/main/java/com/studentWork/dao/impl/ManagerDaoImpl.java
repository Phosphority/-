package com.studentWork.dao.impl;

import com.studentWork.dao.ManagerDao;
import com.studentWork.entity.Manager;
import com.studentWork.utils.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ManagerDaoImpl implements ManagerDao {
    @Override
    public Manager getManagerByNameAndPassword(Manager manager) throws SQLException {
        String sql = "SELECT * FROM tb_manager WHERE manager_password = ? and manager_name = ?";
        Manager newManager = new Manager();
        Connection con = JDBCUtils.getConnection();
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, manager.getManager_password());
        ps.setString(2, manager.getManager_name());
        ResultSet rs = ps.executeQuery();

        if(rs.next()){
            newManager.setManager_id(manager.getManager_id());
            newManager.setManager_name(manager.getManager_name());
            newManager.setManager_password(manager.getManager_password());
            newManager.setManager_state(manager.getManager_state());
        }
        JDBCUtils.release(rs, ps, con);
        return newManager;
    }

    @Override
    public Manager getManagerByAll(Manager manager) throws SQLException {
        String sql = "SELECT * FROM tb_manager WHERE manager_id = ? and manager_name = ? and manager_password = ? and manager_state = ?";
        Manager newManager = new Manager();
        Connection con = JDBCUtils.getConnection();
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, manager.getManager_id());
        ps.setString(2, manager.getManager_name());
        ps.setString(3, manager.getManager_password());
        ps.setString(4, manager.getManager_state());
        ResultSet rs = ps.executeQuery();

        if(rs.next()){
            newManager.setManager_id(manager.getManager_id());
            newManager.setManager_name(manager.getManager_name());
            newManager.setManager_password(manager.getManager_password());
            newManager.setManager_state(manager.getManager_state());
        }
        JDBCUtils.release(rs, ps, con);
        return newManager;
    }

    @Override
    public List<Manager> findAll(Integer nowPage,Integer maxPage) throws SQLException {
        String sql = "SELECT * FROM tb_manager limit ? offset ?";
        List<Manager> managers = new ArrayList<Manager>();
        Connection con = JDBCUtils.getConnection();
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, maxPage);
        ps.setInt(2, nowPage);
        ResultSet rs = ps.executeQuery();

        while(rs.next()){
            Manager manager = new Manager();
            manager.setManager_id(rs.getInt("manager_id"));
            manager.setManager_name(rs.getString("manager_name"));
            manager.setManager_password(rs.getString("manager_password"));
            manager.setManager_state(rs.getString("manager_state"));
            managers.add(manager);
        }
        JDBCUtils.release(rs, ps, con);
        return managers;
    }

    @Override
    public Integer findAllCount() throws SQLException {
        String sql = "SELECT count(*) FROM tb_manager";
        int count = 0;
        Connection con = JDBCUtils.getConnection();
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while(rs.next()){
            count = rs.getInt(1);
        }
        JDBCUtils.release(rs, ps, con);
        return count;
    }

    @Override
    public Integer insert(Manager manager) {
        String sql = "INSERT INTO tb_manager( manager_name,manager_password, manager_state) values(?,?,?) ";
        int row = 0;
        try {
            Connection con = JDBCUtils.getConnection();
            PreparedStatement ps = null;
            ps = con.prepareStatement(sql);
            ps.setString(1, manager.getManager_name());
            ps.setString(2, manager.getManager_password());
            ps.setString(3, manager.getManager_state());
            row = ps.executeUpdate();
            JDBCUtils.release(ps, con);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return row;
    }

    @Override
    public Manager findById(Manager manager) throws SQLException {
        String sql = "SELECT * FROM tb_manager WHERE manager_id = ?";
        Manager newManager = new Manager();
        Connection con = JDBCUtils.getConnection();
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, manager.getManager_id());
        ResultSet rs = ps.executeQuery();

        if(rs.next()){
            newManager.setManager_id(rs.getInt(1));
            newManager.setManager_name(rs.getString(2));
            newManager.setManager_password(rs.getString(3));
            newManager.setManager_state(rs.getString(4));
        }
        JDBCUtils.release(rs, ps, con);
        return newManager;
    }

    public Integer deleteManagerById(Integer manager_id) throws SQLException {
        String sql = "delete from tb_manager WHERE manager_id = ?";
        int row = 0;
        try {
            Connection con = JDBCUtils.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, manager_id);
            row = ps.executeUpdate();
            JDBCUtils.release(ps, con);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return row;
    }


    public Integer modify(Manager manager) {
        String sql = "UPDATE tb_manager set manager_id = ?,manager_name = ?,manager_password = ?,manager_state = ? where manager_name = ?";
        int row = 0;
        try {
            Connection con = JDBCUtils.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, manager.getManager_id());
            ps.setString(2, manager.getManager_name());
            ps.setString(3, manager.getManager_password());
            ps.setString(4, manager.getManager_state());
            ps.setString(5, manager.getManager_name());
            row = ps.executeUpdate();
            JDBCUtils.release(ps, con);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return row;
    }
}
