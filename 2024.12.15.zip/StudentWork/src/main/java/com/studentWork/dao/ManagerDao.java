package com.studentWork.dao;


import com.studentWork.entity.Manager;

import java.sql.SQLException;
import java.util.List;

public interface ManagerDao {
    Manager getManagerByNameAndPassword(Manager manager) throws SQLException;
    Manager getManagerByAll(Manager manager) throws SQLException;
    List<Manager> findAll(Integer nowPage,Integer pageMax) throws SQLException;
    Integer insert(Manager manager) throws SQLException;
    Integer modify(Manager manager) throws SQLException;
    Manager findById(Manager manager) throws SQLException;
    Integer deleteManagerById(Integer manger_id) throws SQLException;
    Integer findAllCount() throws SQLException;
}
