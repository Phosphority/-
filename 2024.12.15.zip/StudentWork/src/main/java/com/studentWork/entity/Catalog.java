package com.studentWork.entity;

import lombok.*;
import lombok.experimental.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class Catalog {
    Integer catalog_id;
    String  catalog_name;
    String  catalog_number;
    String  catalog_state;
}
