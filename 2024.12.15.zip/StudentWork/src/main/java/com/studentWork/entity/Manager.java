package com.studentWork.entity;

import lombok.*;
import lombok.experimental.Accessors;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class Manager implements Serializable {
    Integer manager_id;
    String manager_name;
    String manager_password;
    String manager_state;
}