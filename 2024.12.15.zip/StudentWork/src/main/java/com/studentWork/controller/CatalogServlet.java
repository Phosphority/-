package com.studentWork.controller;

import com.studentWork.entity.Catalog;
import com.studentWork.service.CatalogService;
import com.studentWork.service.impl.CatalogServiceImpl;
import lombok.SneakyThrows;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/catalogServlet")
public class CatalogServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String type = req.getParameter("type");
        switch (type) {
            case "findAll" -> findAll(req, resp);
            case "toReg" -> toReg(req, resp);
            case "register" -> register(req, resp);
            case "modify" -> modify(req, resp);
            case "findById" -> findById(req, resp);
            case "delete" -> delete(req, resp);
            default -> resp.sendError(404);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    public void toReg(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        String path = "WEB-INF/jsp/catalog_reg.jsp";
        request.getRequestDispatcher(path).forward(request, response);
    }

    public void findAll(HttpServletRequest request, HttpServletResponse response){
        CatalogService catalogService = new CatalogServiceImpl();

        try {
            List<Catalog> catalogList = catalogService.findAll();
            request.setAttribute("catalogList", catalogList);
            request.getRequestDispatcher("WEB-INF/jsp/catalog_findAll.jsp").forward(request, response);
        } catch (ServletException | IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void register(HttpServletRequest request, HttpServletResponse response){
        String catalog_name = request.getParameter("catalog_name");
        String catalog_number = request.getParameter("catalog_number");
        Catalog catalog = new Catalog()
                .setCatalog_name(catalog_name)
                .setCatalog_number(catalog_number)
                .setCatalog_state("1");

        try {
            CatalogService catalogService = new CatalogServiceImpl();
            String path = "WEB-INF/jsp/catalog_reg.jsp";
            if(catalogService.insertCatalog(catalog)){
                findAll(request, response);
            }
            request.getRequestDispatcher(path).forward(request, response);
        } catch (ServletException | IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void findById(HttpServletRequest request, HttpServletResponse response){
        Integer catalog_id = Integer.valueOf(request.getParameter("id"));

        CatalogService catalogService = new CatalogServiceImpl();
        try {
            Catalog newCatalog = catalogService.selectCatalogById(catalog_id);
            request.setAttribute("newCatalog", newCatalog);
            String path = "WEB-INF/jsp/catalog_modify.jsp";
            request.getRequestDispatcher(path).forward(request,response);
        } catch (ServletException | IOException e) {
            throw new RuntimeException(e);
        }
    }

    @SneakyThrows
    public void modify(HttpServletRequest request, HttpServletResponse response){
        String catalog_name = request.getParameter("catalog_name");
        String catalog_number = request.getParameter("catalog_number");
        String catalog_state = request.getParameter("catalog_state");
        Integer catalog_id = Integer.valueOf(request.getParameter("catalog_id"));

        Catalog catalog = new Catalog().setCatalog_id(catalog_id)
                .setCatalog_name(catalog_name)
                .setCatalog_number(catalog_number)
                .setCatalog_id(catalog_id)
                .setCatalog_state(catalog_state);

        CatalogService catalogService = new CatalogServiceImpl();
        catalogService.updateCatalogByName(catalog);

        findAll(request, response);
    }

    @SneakyThrows
    public void delete(HttpServletRequest request, HttpServletResponse response){
        Integer catalog_id = Integer.valueOf(request.getParameter("catalog_id"));

        CatalogService catalogService = new CatalogServiceImpl();
        catalogService.deleteCatalogById(catalog_id);
        findAll(request, response);
    }
}
