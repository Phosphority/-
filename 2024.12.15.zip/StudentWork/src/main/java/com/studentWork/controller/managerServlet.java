package com.studentWork.controller;

import com.studentWork.entity.Manager;
import com.studentWork.service.ManagerService;
import com.studentWork.service.impl.ManagerServiceImpl;
import lombok.SneakyThrows;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

@WebServlet("/managerServlet")
public class managerServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String type = req.getParameter("type");
        switch (type) {
            case "login" -> login(req, resp);
            case "findAll" -> {
                try {
                    findAll(req, resp);
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
            case "toReg" -> toReg(req, resp);
            case "register" -> register(req, resp);
            case "modify" -> modify(req, resp);
            case "findById" -> findById(req, resp);
            case "delete" -> delete(req, resp);
            case "logout" -> logout(req, resp);
            default -> resp.sendError(404);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    protected void logout(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        session.invalidate();
        System.out.println(request.getContextPath());
        response.sendRedirect(request.getContextPath()+ "/login");
    }

    public void toReg(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        String path = "WEB-INF/jsp/manager_reg.jsp";
        request.getRequestDispatcher(path).forward(request, response);
    }

    public void login(HttpServletRequest request, HttpServletResponse response){
        String manager_name = request.getParameter("manager_name");
        String manager_password = request.getParameter("manager_password");

        Manager manager = new Manager();
        manager.setManager_name(manager_name);
        manager.setManager_password(manager_password);

        ManagerService managerService = new ManagerServiceImpl();
        try {
            HttpSession session = request.getSession();
            String path = "WEB-INF/jsp/login.jsp";
            if(managerService.login(manager)){
                session.setAttribute("manager_name", manager.getManager_name());
                path = "WEB-INF/jsp/index.jsp";
            }
            request.setAttribute("manager", manager);
            request.getRequestDispatcher(path).forward(request, response);
        } catch (SQLException | ServletException | IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void findAll(HttpServletRequest request, HttpServletResponse response) throws SQLException {
        ManagerService managerService = new ManagerServiceImpl();
        int pageSize = 4;
        Integer maxPage = managerService.findAllCount(pageSize);
        String nowPageS = request.getParameter("nowPage");
        if(nowPageS == null || nowPageS.equals("1") || nowPageS.equals("0")){
            nowPageS = "1";
        }
        Integer nowPage = Integer.parseInt(nowPageS);
        if(nowPage > maxPage){
            nowPage = maxPage;
        }

        try {
            List<Manager> managerList = managerService.findAll(nowPage,maxPage);
            request.setAttribute("managerList", managerList);
            request.setAttribute("nowPage", nowPage);
            request.getRequestDispatcher("WEB-INF/jsp/manager_findAll.jsp").forward(request, response);
        } catch (SQLException | ServletException | IOException e) {
            throw new RuntimeException(e);
        }
    }


    public void register(HttpServletRequest request, HttpServletResponse response){
        String manager_name = request.getParameter("manager_name");
        String manager_password = request.getParameter("manager_password");
        Manager manager = new Manager()
                .setManager_name(manager_name)
                .setManager_password(manager_password)
                .setManager_state("1");

        try {
            ManagerService managerService = new ManagerServiceImpl();
            String path = "WEB-INF/jsp/manager_reg.jsp";
            if(managerService.insert(manager)){
                findAll(request, response);
            }
            request.getRequestDispatcher(path).forward(request, response);
        } catch (SQLException | ServletException | IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void findById(HttpServletRequest request, HttpServletResponse response){
        Integer manager_id = Integer.valueOf(request.getParameter("id"));
        Manager manager = new Manager().setManager_id(manager_id);

        ManagerService managerService = new ManagerServiceImpl();
        try {
            Manager manager1 = managerService.findById(manager);
            request.setAttribute("manager", manager1);
            String path = "WEB-INF/jsp/manager_modify.jsp";
            request.getRequestDispatcher(path).forward(request,response);
        } catch (SQLException | ServletException | IOException e) {
            throw new RuntimeException(e);
        }
    }

    @SneakyThrows
    public void modify(HttpServletRequest request, HttpServletResponse response){
        String manager_name = request.getParameter("manager_name");
        String manager_password = request.getParameter("manager_password");
        String manager_state = request.getParameter("manager_state");
        Integer manager_id = Integer.valueOf(request.getParameter("manager_id"));

        Manager manager = new Manager()
                .setManager_name(manager_name)
                .setManager_password(manager_password)
                .setManager_id(manager_id)
                .setManager_state(manager_state);


        ManagerService managerService = new ManagerServiceImpl();
        managerService.modify(manager);

        findAll(request, response);
    }

    @SneakyThrows
    public void delete(HttpServletRequest request, HttpServletResponse response){
        Integer manager_id = Integer.valueOf(request.getParameter("manager_id"));

        ManagerService managerService = new ManagerServiceImpl();
        managerService.deleteManagerById(manager_id);
        findAll(request, response);
    }
}
